1. I included both the bin and src because some images need to be loaded, and I am uncertain if they will load if I do not keep all my folders exactly as I had them in my project.

2. This version has been thoroughly tested and I can't find any bugs, even though it is almost 2 hours late.

3. The GUI is started via the Viewer class.

4. This implementation supports adding new critters that subclass Critter.

5. I used a different shape representation for my critters than was recommended in the instructions, because I didn't have the starter code at the time.

6. The code is very messy to read in places, but as a whole it seems to work without bugs. (There are also still System.out.println() statements used in debugging that haven't been taken out yet.)

7. The GUI has all nodes labelled with CSS selectors so that styling and spacing could readily be improved if there was more time. (I was only able to implement CSS for a few components.)