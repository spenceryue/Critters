Berserker and ZigZagger are my two custom critters.
Berserker kills everyone with a special move when it has only one member of itself left alive (uses reflection to do this).
ZigZagger moves in zig zagging directions over time.