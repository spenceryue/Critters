Berserker and ZigZagger are my two custom critters.
Berserker kills everyone with a special move when it has only one member of itself left alive.
ZigZagger moves in zig zagging directions over time.

Also, Berserker heals itself after doing the special move by manipulating an Algae.