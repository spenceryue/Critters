package project4;

import java.util.ArrayList;
import java.util.HashMap;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Bounds;
import javafx.geometry.Rectangle2D;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Viewer extends Application {

	public static void main(String[] args) {launch(args);}
	
	final static boolean GUI = true;
	final static double screenWidth;
	final static double screenHeight;
	static double stageWidth = Icon.fontSize*3*Params.world_width+400;
	static double stageHeight = Icon.fontSize*3*Params.world_height > 400 ? Icon.fontSize*3*Params.world_height : 400;
	
	static GridPane layer2_right_row0_world; static GridPane world; static Text layer2_step_counter; static Button layer4_clear; static Button layer4_back;
	static {
		Rectangle2D screenSize = Screen.getPrimary().getVisualBounds();
		screenWidth = screenSize.getWidth();
		screenHeight = screenSize.getHeight();
		if (stageWidth > screenWidth)
			stageWidth = screenWidth;
		if (stageHeight > screenHeight)
			stageHeight = screenHeight;
		layer2_right_row0_world = world = new GridPane();
		layer2_right_row0_world.setId("layer2-right-row0-world");
		layer2_step_counter = new Text("Step 0");
		layer2_step_counter.setId("layer2-step-counter");
		layer4_clear = new Button("Clear");
		layer4_back = new Button("x");
	}
	
	static HBox layer0_white_bg = new HBox();
	static int steps = 0;
	static double speed = 1.0;
	static String statSelect;
	static boolean skip = false;
//	static GridPane world;
	static boolean playing = false;
	
	private static ArrayList<StatCard> statCards;
	private static Image[] icons = {new Image("\\images\\icon_big_green_bordered.png"),
			new Image("\\images\\icon_small_green_bordered.png") };
	private static boolean entered = false;
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		Scene s = new Scene(layer0_white_bg);
		primaryStage.setScene(s);
		primaryStage.setWidth(stageWidth);
		primaryStage.setHeight(stageHeight);
		primaryStage.setResizable(true);
		primaryStage.setTitle("Critters");
		primaryStage.getIcons().addAll(icons);
		primaryStage.centerOnScreen();
		layer0_white_bg.setId("layer0-white-bg");
		
			VBox layer1_left_pane = new VBox();
			layer1_left_pane.setId("layer1-left_pane");
			layer1_left_pane.setMaxWidth(420);
			layer1_left_pane.minWidthProperty().bind(layer1_left_pane.prefWidthProperty());;
			layer0_white_bg.getChildren().add(layer1_left_pane);
			
				HBox layer2_left_row0_header = new HBox();
				layer2_left_row0_header.setId("layer2-left-row0-header");
				layer1_left_pane.getChildren().add(layer2_left_row0_header);
				
					Text layer3_welcome = new Text("Welcome ");
					layer3_welcome.setId("layer3-welcome");
					layer2_left_row0_header.getChildren().add(layer3_welcome);
	
					Text layer3_critter_player = new Text("Critter Player");
					layer3_critter_player.setId("layer3-critter-player");
					layer2_left_row0_header.getChildren().add(layer3_critter_player);
					
					Text layer3_exclamation= new Text("!");
					layer3_exclamation.setId("layer3-exclamation");
					layer2_left_row0_header.getChildren().add(layer3_exclamation);
									
				HBox layer2_left_row1_controls_grid = new HBox();
				layer2_left_row1_controls_grid.setId("layer2-left-row1-controls-grid");
				layer1_left_pane.getChildren().add(layer2_left_row1_controls_grid);
				
					VBox layer3_left_column1 = new VBox();
					layer3_left_column1.setId("layer3-left-column1");
					layer2_left_row1_controls_grid.getChildren().add(layer3_left_column1);
				
						CustomTextField layer4_add_a_critter = new CustomTextField("Add a Critter","layer4-add-a-critter");
						layer3_left_column1.getChildren().add(layer4_add_a_critter.container);
						
						CustomTextField layer4_how_many_steps = new CustomTextField("How Many Steps?","layer4-how-many-steps");
						layer3_left_column1.getChildren().add(layer4_how_many_steps.container);
					
					VBox layer3_left_column2 = new VBox();
					layer3_left_column2.setId("layer3-left-column2");
					layer2_left_row1_controls_grid.getChildren().add(layer3_left_column2);
					
						CustomTextField layer4_how_many_critters = new CustomTextField("How Many Critters?","layer4-how-many-critters");
						layer3_left_column2.getChildren().add(layer4_how_many_critters.container);
						
						CustomSlider layer4_speed = new CustomSlider("Speed","layer4-speed");
						layer3_left_column2.getChildren().add(layer4_speed.container);
						
				HBox layer2_left_row2_submit_box = new HBox();
				layer2_left_row2_submit_box.setId("layer2-left-row2-submit-box");
				layer1_left_pane.getChildren().add(layer2_left_row2_submit_box);
				
					CustomToggleSet layer3_skip_to_finish = new CustomToggleSet("layer3-skip-to-finish","Skip to Finish? ","Y","N");
					layer2_left_row2_submit_box.getChildren().add(layer3_skip_to_finish.container);
					
					Button layer3_go = new Button("Go!");
					layer3_go.setOnMouseClicked(new EventHandler<MouseEvent>() {
						private void init() {
							layer2_step_counter.setText("Steps Left: "+steps);
							layer2_left_row1_controls_grid.setDisable(true);
							layer3_go.setText("Pause");
							copy = steps-1;
							routine.setCycleCount(--steps);
							playing = true;
							Critter.worldTimeStep();
							Critter.displayWorld();
						}
						int count=0;
						boolean ignore = false;
						int copy=0;
						Timeline routine = new Timeline(
								new KeyFrame(
										Duration.millis(1000/speed),
										new EventHandler<ActionEvent>() {
											public void handle(ActionEvent e){
												if(steps > 0) {
											Critter.worldTimeStep();
											Critter.displayWorld();
											world.setOpacity(1);
											layer2_step_counter.setText("Steps Left: "+steps);
											routine.playFromStart();
											steps--;
											}else {
												layer2_step_counter.setText("Steps Left: "+steps);
												world.setOpacity(1);
												conclude();
											}
											}
										},
										new KeyValue(layer3_go.textProperty(), "Pause"),
										new KeyValue(world.opacityProperty(), 0),
										new KeyValue(layer2_step_counter.textProperty(),"Step Left: "+copy--))
								);
						
						int i=1;
						@Override
						public void handle(MouseEvent arg0) {
							if (ignore || steps <= 0)
								return;
							System.out.println(i++);
							if (!playing) {
								if (skip) {
									ignore = true;
									while (steps > 0) {
										Critter.worldTimeStep();
										Critter.displayWorld();
										steps--;
									}
									conclude();
									return;
								}
								if (count++==0)
									init();
								else
									transitionToPlay();
								routine.play();
							} else
								routine.stop();
								transitionToPause();
						}
						
						private void transitionToPlay(){
							layer2_left_row1_controls_grid.setDisable(true);
							layer3_go.setText("Pause");
							playing = true;
							}
						private void transitionToPause(){
							layer2_left_row1_controls_grid.setDisable(false);
							layer3_go.setText("Go!");
							playing = false;
							}
						private void conclude() {
							layer3_go.setText("Go!");
							
							playing = false;
							
							count =0;
							
							routine.stop();

				        	CustomTextField.clearControls();
				        	
				        	steps = 0;
				        	
				        	layer4_speed.slider.adjustValue(3.0);
				        	
				        	layer3_skip_to_finish.no.setSelected(true);
				        	
				        	layer4_back.getOnMouseClicked().handle(null);
						}
						
					});
					layer2_left_row2_submit_box.getChildren().add(layer3_go);
				
				VBox layer2_left_row3_stats_box = new VBox();
				layer2_left_row3_stats_box.setId("layer2-left-row3-stats-box");
				VBox.setVgrow(layer2_left_row3_stats_box, Priority.ALWAYS);
				layer1_left_pane.getChildren().add(layer2_left_row3_stats_box);
				
					HBox layer3_stats_select = new HBox();
					layer3_stats_select.setId("layer3-stats-select");
					layer2_left_row3_stats_box.getChildren().add(layer3_stats_select);
				
						Text layer4_stats_for = new Text("Stats for ");
						layer4_stats_for.setId("layer4-stats-for");
						layer3_stats_select.getChildren().add(layer4_stats_for);
					
						ComboBox<String> layer4_all_critters = new ComboBox<String>();
						layer4_all_critters.setId("layer4-all-critters");
						layer4_all_critters.setEditable(true);
						String special = "All Critters";
						layer4_all_critters.getItems().add(special);
						layer4_all_critters.getItems().addAll(Main.classes);
						layer4_all_critters.setOnAction((event) -> {
							if (entered)
								return;
							
							entered = true;
							String selected = layer4_all_critters.valueProperty().toString() != null ?
									layer4_all_critters.valueProperty()
									.toString()
									.replace("ObjectProperty [bean: ComboBox[id=layer4-all-critters, styleClass=combo-box-base combo-box], name: value, value: ", "")
									: null;
							selected = selected != null ? selected.replace("]", "") : null;
						    //String selected = layer4_all_critters.getSelectionModel().getSelectedItem();
							if (selected != null && special.toLowerCase().equals(selected.toLowerCase())) {
						    	selected = special;
						    	layer0_white_bg.lookup("#layer5-all-view").setVisible(true);
								layer0_white_bg.lookup("#layer5-all-view").setManaged(true);
								layer0_white_bg.lookup("#layer5-all-view").toFront();
								layer0_white_bg.lookup("#layer5-single-view").setVisible(false);
								layer0_white_bg.lookup("#layer5-single-view").setManaged(false);
								layer0_white_bg.lookup("#layer5-single-view").toBack();
								
								((Group) layer0_white_bg.lookup("#layer6-left")).getChildren().clear();
								((StackPane) layer0_white_bg.lookup("#layer6-details")).getChildren().clear();
								
								for (StatCard sc : statCards)
									sc.refresh();
								
							} else if (selected != null && (selected = Main.match(selected)) != null) {
								layer0_white_bg.lookup("#layer5-single-view").setVisible(true);
								layer0_white_bg.lookup("#layer5-single-view").setManaged(true);
								layer0_white_bg.lookup("#layer5-single-view").toFront();
								layer0_white_bg.lookup("#layer5-all-view").setVisible(false);
								layer0_white_bg.lookup("#layer5-all-view").setManaged(false);
								layer0_white_bg.lookup("#layer5-all-view").toBack();
								
								((Group) layer0_white_bg.lookup("#layer6-left")).getChildren().clear();
								((StackPane) layer0_white_bg.lookup("#layer6-details")).getChildren().clear();
								for (StatCard sc : statCards)
									if (sc.name.getText().equals(selected)) {
										((Group) layer0_white_bg.lookup("#layer6-left")).getChildren().add(new StatCard(sc.c).container);
										((StackPane) layer0_white_bg.lookup("#layer6-details")).getChildren().add(sc.getDetails());
										break;
									}
								
							} else {
					    		layer4_all_critters.setValue("");
					    		entered = false;
					    		return;
				    		}
							
							statSelect = selected;
						    layer0_white_bg.lookup("#layer3-stats-display").requestFocus();
						//    layer4_all_critters.setValue("");
						    layer4_all_critters.setPromptText(selected);

						    System.out.println(selected);
						    entered=false;
						});
						layer4_all_critters.setPromptText("All Critters");
						layer3_stats_select.getChildren().add(layer4_all_critters);
						
//						Button layer4_back = new Button("x");
						layer4_back.setId("layer4-back");
						layer4_back.setOnMouseClicked((event) -> {
							statSelect = special;
							layer4_all_critters.setPromptText(special);
							layer4_all_critters.setValue(special);
						});
						layer3_stats_select.getChildren().add(layer4_back);
						
					ScrollPane layer3_stats_display = new ScrollPane();
					layer3_stats_display.setId("layer3-stats-display");
					VBox.setVgrow(layer3_stats_display, Priority.ALWAYS);
					layer2_left_row3_stats_box.getChildren().add(layer3_stats_display);

						// update layer4_critters_clip_box contents' contents with "StatCards"
						// for each created Critter
						HBox layer4_critters_clip_box = new HBox();
						layer4_critters_clip_box.setId("layer4-critters-clip-box");
						layer3_stats_display.setContent(layer4_critters_clip_box);
						
							TilePane layer5_all_view = new TilePane();
							layer5_all_view.setId("layer5-all-view");
							layer4_critters_clip_box.getChildren().add(layer5_all_view);
							
								statCards = new ArrayList<StatCard>(Main.classes.size());
								for (String p : Main.classes) {
									statCards.add(new StatCard((Critter)Class.forName("project4."+p).newInstance() ) );
									layer5_all_view.getChildren().add(statCards.get(statCards.size()-1).container);
								}
							
							HBox layer5_single_view = new HBox();
							layer5_single_view.setId("layer5-single-view");
							layer4_critters_clip_box.getChildren().add(layer5_single_view);
							
								Group layer6_left = new Group();
								layer6_left.setId("layer6-left");
								layer5_single_view.getChildren().add(layer6_left);
								
								StackPane layer6_details = new StackPane();
								layer6_details.setId("layer6-details");
								layer5_single_view.getChildren().add(layer6_details);
						
			VBox layer1_right_pane = new VBox();
			layer1_right_pane.setId("layer1-right_pane");
			layer0_white_bg.getChildren().add(layer1_right_pane);
			
//				Text layer2_step_counter = new Text("Step 0");
//				layer2_step_counter.setId("layer2-step-counter");
				layer1_right_pane.getChildren().add(layer2_step_counter);
				
				ScrollPane layer2_right_world_scroll_box = new ScrollPane();
				layer2_right_world_scroll_box.setId("layer2-right-world-scroll-box");
				layer2_right_world_scroll_box.setPannable(true);
				layer2_right_world_scroll_box.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
				layer2_right_world_scroll_box.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
				layer1_right_pane.getChildren().add(layer2_right_world_scroll_box);
			
//				GridPane layer2_right_row0_world = world = new GridPane();
//				layer2_right_row0_world.setId("layer2-right-row0-world");
				//layer1_right_pane.getChildren().add(layer2_right_row0_world);
				layer2_right_world_scroll_box.setContent(layer2_right_row0_world);
				
				HBox layer2_right_row1_settings_box = new HBox();
				layer2_right_row1_settings_box.setId("layer2-right-row1-settings-box");
				layer1_right_pane.getChildren().add(layer2_right_row1_settings_box);
				
					HBox layer3_settings_clipped_box = new HBox();
					layer3_settings_clipped_box.setId("layer3-settings-clipped-box");
					layer2_right_row1_settings_box.getChildren().add(layer3_settings_clipped_box);
			
						CustomTextField layer4_set_seed = new CustomTextField("Set Seed","layer4-set-seed");
						layer3_settings_clipped_box.getChildren().add(layer4_set_seed.container);
						
				/*		ImageView layer4_cog_icon = new ImageView(new Image("\\images\\cog_icon.png"));
						layer4_cog_icon.fitHeightProperty().bind(layer3_settings_clipped_box.heightProperty());
				        layer4_cog_icon.setPreserveRatio(true);
				        layer4_cog_icon.setSmooth(true);
				        layer4_cog_icon.setCache(true);
				        layer4_cog_icon.setId("layer4-cog-icon");
				        layer3_settings_clipped_box.getChildren().add(layer4_cog_icon);
				        layer4_cog_icon.fitHeightProperty().bind(layer4_set_seed.container.heightProperty());
				        layer4_cog_icon.maxHeight(layer4_cog_icon.getFitHeight());
				 */       
//				        Button layer4_clear = new Button("Clear");
				        layer4_clear.setId("layer4-clear");
				        layer4_clear.setOnMouseClicked((event) -> {
				        	world.getChildren().clear();
				        	spaceMap.clear();
				        	java.util.List<Critter> L =null;
				        	try { L = Critter.getInstances("Critter"); }
				        	catch (Exception e) {}
				        	for (Critter c : L)
				        		while (c.getEnergy() > 0) {
				        			c.walk(0); c.run(0); c.look(0);
				        		}
				        	initWorldGrid();
				        	
				        	CustomTextField.clearControls();
				        	
				        	steps = 0;
				        	
				        	layer4_speed.slider.adjustValue(3.0);
				        	
				        	layer3_skip_to_finish.no.setSelected(true);
				        	
				        	layer4_back.getOnMouseClicked().handle(null);
				        	// clear statCards too...
				        });
				        layer3_settings_clipped_box.getChildren().add(layer4_clear);
				        
				 /*       Rectangle clip_mask = new Rectangle();
						clip_mask.layoutXProperty().bind(layer2_right_row1_settings_box.layoutXProperty());
						clip_mask.layoutYProperty().bind(layer2_right_row1_settings_box.layoutYProperty());
						clip_mask.widthProperty().bind(layer4_set_seed.container.widthProperty());
						clip_mask.heightProperty().bind(layer4_set_seed.container.heightProperty());
						layer3_settings_clipped_box.setClip(clip_mask);
				*/
			
        s.getStylesheets().add("project4/critters.css"); 
        primaryStage.setScene(s);
        
		primaryStage.show();
		initWorldGrid();
	}
	
	private static void initWorldGrid() {
		for (int i=0; i<Params.world_width; i++) {
			Icon filler = new Icon(new Algae());
			filler.body.setVisible(false);

			spaceMap.put(new Point(i,0), filler.body);
			world.add(filler.body, i, 0);
			}
		for (int j=1; j<Params.world_height; j++) {
			Icon filler = new Icon(new Algae());
			filler.body.setVisible(false);
			
			spaceMap.put(new Point(0,j), filler.body);
			world.add(filler.body, 0, j);
		}	
	}
	
	static HashMap<Point,Node> spaceMap = new HashMap<Point,Node>();
	static Group trash = new Group();
	static Scene junk = new Scene(trash);
}
